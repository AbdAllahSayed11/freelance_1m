# scraper/database.py
import os
import sqlite3

class Database:
    """
    Database handler for storing scraped data.
    """
    DB_PATH = "scraper_data.db"

    def __init__(self):
        self.conn = sqlite3.connect(self.DB_PATH)
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        """Create tables if they do not exist."""
        # self.cursor.execute("""
        #     CREATE TABLE IF NOT EXISTS doctors (
        #         id INTEGER PRIMARY KEY AUTOINCREMENT,
        #         name TEXT,
        #         specialty TEXT,
        #         location TEXT,
        #         profile_url TEXT UNIQUE,
        #         image_url TEXT,
        #         source TEXT
        #     )
        # """)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            specialty TEXT,
            location TEXT,
            profile_url TEXT,
            image_url TEXT,
            source TEXT,
            UNIQUE(name, profile_url, image_url, source)
            )
        """)

        self.conn.commit()

    def insert_doctor(self, name, specialty, location, profile_url, image_url, source):
        """Insert doctor data while avoiding duplicates."""
        self.cursor.execute("""
            INSERT OR IGNORE INTO doctors (name, specialty, location, profile_url, image_url, source)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (name, specialty, location, profile_url, image_url, source))
        self.conn.commit()

    def close(self):
        """Close the database connection."""
        self.conn.close()