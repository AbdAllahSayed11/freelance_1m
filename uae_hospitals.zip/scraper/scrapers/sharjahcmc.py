import requests
from bs4 import BeautifulSoup
import time
import logging
import traceback
from scraper.database import Database
from urllib.parse import urljoin

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sharjahcmc_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def extract_doctors(specialty_url, specialty_name):
    """Extract doctor information from a Sharjah Corniche Hospital specialty page."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(specialty_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch specialty page {specialty_url}. Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        # Primary selector for visible doctor columns
        doctor_items = soup.select(
            '.elementor-section.elementor-inner-section '
            '.elementor-column.elementor-col-25.elementor-inner-column'
            ':not(.elementor-hidden-desktop):not(.elementor-hidden-tablet):not(.elementor-hidden-mobile)'
        )
        
        # Fallback selector if primary fails
        if not doctor_items:
            logger.warning(f"No doctors found with primary selector for {specialty_url}. Trying fallback selector.")
            doctor_items = soup.select('.elementor-column.elementor-inner-column')
        
        logger.debug(f"Found {len(doctor_items)} doctor columns in specialty {specialty_name}")
        
        doctors_data = []
        base_url = "https://www.sharjahcmc.ae"
        for item in doctor_items:
            try:
                # Extract name
                name_elem = item.select_one('.elementor-image-box-title')
                name = name_elem.text.strip() if name_elem else ""
                if not name or name == "Dr. Name" or name == "N/A":
                    logger.warning(f"Skipping doctor with invalid name in {specialty_name}. Item HTML: {str(item)[:200]}...")
                    continue
                
                # Extract specialty
                spec_elem = item.select_one('.elementor-image-box-description')
                specialty = spec_elem.text.strip() if spec_elem else ""
                if not specialty or specialty == "Dr. Position" or specialty == "N/A":
                    logger.warning(f"Skipping doctor with invalid specialty in {specialty_name}. Item HTML: {str(item)[:200]}...")
                    continue
                
                # Extract profile URL (prefer button link, fallback to image link)
                profile_link = item.select_one('.elementor-button-wrapper a') or item.select_one('.elementor-widget-image a')
                profile_url = urljoin(base_url, profile_link['href']) if profile_link and profile_link.get('href') and profile_link['href'] != "#" else ""
                if not profile_url:
                    logger.warning(f"Skipping doctor with invalid profile URL in {specialty_name}. Item HTML: {str(item)[:200]}...")
                    continue
                
                # Extract image URL
                img_elem = item.select_one('.elementor-widget-image img')
                image_url = urljoin(base_url, img_elem['src']) if img_elem and img_elem.get('src') else "N/A"
                
                # Format location
                location = f"Amina Group - Sharjah Corniche Hospital, Halwan Suburb, {specialty_name}"
                
                doctor = {
                    'name': name,
                    'specialty': specialty,
                    'location': location,
                    'profile_url': profile_url,
                    'image_url': image_url,
                    'source': specialty_url
                }
                doctors_data.append(doctor)
                logger.debug(f"Extracted doctor: {name} - {specialty} - {profile_url}")
            
            except Exception as e:
                logger.warning(f"Error parsing doctor in {specialty_name}: {str(e)}. Item HTML: {str(item)[:200]}...")
                logger.debug(f"Stack trace: {traceback.format_exc()}")
                continue
        
        logger.info(f"Extracted {len(doctors_data)} valid doctors from specialty {specialty_name}")
        return doctors_data
        
    except requests.RequestException as e:
        logger.error(f"Error fetching {specialty_url}: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
        return []
    except Exception as e:
        logger.error(f"Unexpected error in extract_doctors for {specialty_url}: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
        return []

def scrape():
    """Main function to scrape doctor data from Sharjah Corniche Hospital Our Doctors page."""
    base_url = "https://www.sharjahcmc.ae/our-doctors/"
    logger.info("Starting Sharjah Corniche Hospital Our Doctors scraping process")
    
    # Fetch the main page to get specialty links
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(base_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page {base_url}. Status code: {response.status_code}")
            return
        
        soup = BeautifulSoup(response.content, 'html.parser')
        nav_menu = soup.select_one('ul#menu-1-17b34650')
        if not nav_menu:
            logger.error("No specialty navigation menu found on the page.")
            return
        
        specialties = []
        for item in nav_menu.find_all('li', class_='menu-item'):
            link = item.find('a', class_='hfe-menu-item')
            if link and link.get('href'):
                specialties.append({
                    "url": link['href'],
                    "name": link.text.strip()
                })
        
        if not specialties:
            logger.error("No valid specialties found in the navigation menu.")
            return
        
        logger.info(f"Found {len(specialties)} specialties to scrape")
        
        # Initialize database connection
        db = None
        try:
            db = Database()
        except Exception as e:
            logger.error(f"Failed to initialize database: {str(e)}")
            logger.debug(f"Stack trace: {traceback.format_exc()}")
            return
        
        total_doctors = 0
        for specialty in specialties:
            logger.info(f"Scraping specialty: {specialty['name']} ({specialty['url']})")
            doctors = extract_doctors(specialty['url'], specialty['name'])
            
            if not doctors:
                logger.warning(f"No valid doctors found for specialty {specialty['name']}.")
                continue
            
            # Insert doctors into database
            for doctor in doctors:
                try:
                    db.insert_doctor(
                        name=doctor['name'],
                        specialty=doctor['specialty'],
                        location=doctor['location'],
                        profile_url=doctor['profile_url'],
                        image_url=doctor['image_url'],
                        source=doctor['source']
                    )
                    logger.debug(f"Added doctor to database: {doctor['name']} - {doctor['specialty']}")
                    total_doctors += 1
                except Exception as e:
                    logger.warning(f"Failed to insert doctor {doctor['name']} in {specialty['name']}: {str(e)}")
                    logger.debug(f"Stack trace: {traceback.format_exc()}")
                    continue
            
            time.sleep(2)  # Be polite to the server
        
        logger.info(f"Sharjah Corniche Hospital Our Doctors scraping completed. Total doctors added: {total_doctors}")
        
    except requests.RequestException as e:
        logger.error(f"Error fetching initial page {base_url}: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
    except Exception as e:
        logger.error(f"Unexpected error during scraping: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
    finally:
        if 'db' in locals() and db is not None:
            try:
                db.close()
            except Exception as e:
                logger.error(f"Error closing database: {str(e)}")
                logger.debug(f"Stack trace: {traceback.format_exc()}")