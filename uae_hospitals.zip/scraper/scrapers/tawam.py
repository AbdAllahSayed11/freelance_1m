import requests
from bs4 import BeautifulSoup
import time
import logging
import traceback
from urllib.parse import urljoin
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import random
import sqlite3
import threading
import re
from scraper.database import Database

# Configure logging (unchanged)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('tawam_doctor_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# extract_doctor function (unchanged, included for context)
def extract_doctor(url):
    """Extract doctor information from a single doctor detail page if it contains 'Tawam Hospital, Abu Dhabi'."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    with requests.Session() as session:
        retries = Retry(
            total=3,
            backoff_factor=2,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"],
            raise_on_status=False
        )
        session.mount('https://', HTTPAdapter(max_retries=retries))
        
        base_timeout = 30
        for attempt in range(1, 4):
            try:
                timeout = base_timeout + (attempt - 1) * 10
                response = session.get(url, headers=headers, timeout=timeout)
                
                if response.status_code == 429:
                    sleep_time = 2 ** attempt + random.uniform(0.1, 0.5)
                    logger.info(f"429 Too Many Requests for {url}. Sleeping {sleep_time:.2f}s before retry {attempt}/3")
                    time.sleep(sleep_time)
                    continue
                if response.status_code != 200:
                    logger.info(f"Skipping {url}. Status code: {response.status_code}")
                    return None
                
                soup = BeautifulSoup(response.text, 'lxml')
                text = soup.get_text()
                if not re.search(r"Tawam Hospital\s*,\s*Abu Dhabi", text, re.IGNORECASE):
                    logger.info(f"Skipping {url}. 'Tawam Hospital, Abu Dhabi' not found in text.")
                    return None
                
                logger.info(f"Found doctor at Tawam Hospital, Abu Dhabi ...")
                name_elem = soup.select_one('div.doctorSingleHeading h1')
                name = name_elem.text.strip() if name_elem else ""
                if not name or name == "N/A":
                    logger.info(f"Skipping {url}. Invalid name. HTML snippet: {str(soup)[:200]}...")
                    return None
                
                specialties = []
                specialty_elem = soup.select_one('div.doctorSingleHeading h2')
                if specialty_elem:
                    specialties.append(specialty_elem.text.strip())
                
                education_elems = soup.select('p.doctorEducation span')
                for elem in education_elems:
                    specialty_text = elem.text.strip()
                    if specialty_text:
                        specialties.append(specialty_text)
                
                specialty = " ".join(specialties) if specialties else "N/A"
                
                img_elem = soup.select_one('div.doctorSingleImage img')
                image_url = "N/A"
                if img_elem:
                    src = img_elem.get('src', '')
                    data_src = img_elem.get('data-src', '')
                    data_lazy_src = img_elem.get('data-lazy-src', '')
                    
                    logger.info(f"Image attributes for {name}: src={src[:50]}, data-src={data_src[:50]}, data-lazy-src={data_lazy_src[:50]}")
                    
                    selected_src = src
                    if (not src or src.startswith('data:image') or src == ''):
                        selected_src = data_src or data_lazy_src or ''
                    
                    if selected_src and not selected_src.startswith('data:image'):
                        if selected_src.lower().endswith(('.jpg', '.jpeg', '.png')):
                            image_url = urljoin(url, selected_src)
                        else:
                            logger.info(f"Invalid image extension for {name} on {url}. Src: {selected_src[:50]}... Img HTML: {str(img_elem)[:200]}...")
                    else:
                        logger.info(f"No valid image source for {name} on {url}. Src: {src[:50]}... Data-src: {data_src[:50]}... Img HTML: {str(img_elem)[:200]}...")
                else:
                    logger.info(f"No image element found for {name} on {url}. HTML snippet: {str(soup)[:200]}...")
                
                doctor = {
                    'name': name,
                    'specialty': specialty,
                    'location': "Tawam Hospital, Abu Dhabi",
                    'profile_url': url,
                    'image_url': image_url,
                    'source': url
                }
                logger.info(f"Extracted doctor: {name} - {specialty} - {url} - {image_url}")
                return doctor
            
            except (requests.RequestException, ConnectionError, TimeoutError) as e:
                logger.info(f"Attempt {attempt}/3 failed for {url}: {str(e)}")
                if attempt == 3:
                    logger.error(f"Max retries reached for {url}: {str(e)}")
                    logger.info(f"Stack trace: {traceback.format_exc()}")
                    return None
                time.sleep(2 + random.uniform(0.1, 0.5))
            except Exception as e:
                logger.error(f"Unexpected error fetching {url}: {str(e)}")
                logger.info(f"Stack trace: {traceback.format_exc()}")
                return None

def worker(url_list, lock):
    """Worker function to process URLs from the shared list and insert doctor data into the database."""
    db = None
    try:
        db = Database()
        while True:
            url = None
            with lock:
                if url_list:  # Check if there are URLs left
                    url = url_list.pop(0)  # Pop the first URL
                else:
                    logger.info(f"Thread {threading.current_thread().name} found no more URLs, exiting.")
                    break
            
            try:
                doctor = extract_doctor(url)
                if doctor:
                    required_fields = ['name', 'specialty', 'location', 'profile_url', 'image_url', 'source']
                    missing_fields = [field for field in required_fields if field not in doctor or not doctor[field]]
                    if missing_fields:
                        logger.info(f"Skipping insertion for {doctor.get('name', 'Unknown')} due to missing fields: {missing_fields}. Doctor data: {doctor}")
                    else:
                        for attempt in range(1, 3):
                            try:
                                db.insert_doctor(
                                    name=doctor['name'],
                                    specialty=doctor['specialty'],
                                    location=doctor['location'],
                                    profile_url=doctor['profile_url'],
                                    image_url=doctor['image_url'],
                                    source=doctor['source']
                                )
                                logger.info(f"Added doctor to database: {doctor['name']} - {doctor['specialty']} - {doctor['image_url']}")
                                break
                            except sqlite3.OperationalError as e:
                                if attempt == 2:
                                    logger.error(f"Failed to insert doctor {doctor.get('name', 'Unknown')} after retries: {str(e)}")
                                    break
                                logger.info(f"Database error for {doctor.get('name', 'Unknown')} (attempt {attempt}/2): {str(e)}. Retrying...")
                                time.sleep(0.5 + random.uniform(0.1, 0.2))
                            except Exception as e:
                                logger.error(f"Unexpected error inserting doctor {doctor.get('name', 'Unknown')}: {str(e)}")
                                break
            except Exception as e:
                logger.error(f"Unexpected error in worker for URL {url}: {str(e)}")
                logger.info(f"Stack trace: {traceback.format_exc()}")
    except Exception as e:
        logger.error(f"Worker thread {threading.current_thread().name} failed: {str(e)}")
        logger.info(f"Stack trace: {traceback.format_exc()}")
    finally:
        if db:
            try:
                db.close()
                logger.info(f"Thread {threading.current_thread().name} closed database connection.")
            except Exception as e:
                logger.error(f"Error closing database in thread {threading.current_thread().name}: {str(e)}")

def scrape():
    """Main function to scrape doctor data from Tawam Hospital doctor detail pages using 10 threads."""
    base_url = "https://skmc-seha.brahui.dev/doctor-detail/"
    logger.info("Starting Tawam Hospital doctor scraping process")
    
    # Initialize shared URL list and lock
    url_list = []
    lock = threading.Lock()
    
    # Populate the URL list
    for number in range(1, 1001):
        url = f"{base_url}{number}"
        url_list.append(url)
    
    # Start 10 worker threads
    threads = []
    for i in range(10):
        t = threading.Thread(target=worker, args=(url_list, lock), name=f"Worker-{i+1}")
        t.start()
        threads.append(t)
        logger.info(f"Started thread {t.name}")
    
    # Wait for all threads to finish
    for t in threads:
        t.join()
        logger.info(f"Thread {t.name} has joined.")
    
    logger.info("Tawam Hospital doctor scraping completed.")