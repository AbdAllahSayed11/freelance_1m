import requests
from bs4 import BeautifulSoup
import time
import logging
from scraper.database import Database
from urllib.parse import urljoin

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('uaeu_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def extract_doctors(team_url, specialty):
    """Extract person information from a UAEU Spotlights page."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(team_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page {team_url}. Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        spotlight_list = soup.select('.spotlight-list .list-item')
        
        persons_data = []
        base_url = "https://www.uaeu.ac.ae"
        for item in spotlight_list:
            try:
                # Extract name
                name_elem = item.select_one('h6')
                name = name_elem.text.strip().replace('[...]', '') if name_elem else "N/A"
                
                # Extract profile URL
                profile_link = item.select_one('a.main-video-element')
                profile_url = urljoin(base_url, profile_link['href']) if profile_link and profile_link.get('href') else "N/A"
                
                # Extract image URL
                img_elem = item.select_one('.video-hi img')
                image_url = urljoin(base_url, img_elem['src']) if img_elem and img_elem.get('src') else "N/A"
                
                # Hardcoded location
                location = "Al Ain, UAE"
                
                if name != "N/A":
                    persons_data.append({
                        'name': name,
                        'specialty': specialty,
                        'location': location,
                        'profile_url': profile_url,
                        'image_url': image_url,
                        'source': team_url
                    })
                else:
                    logger.warning(f"Skipping person with missing name at {team_url}. Item HTML: {str(item)[:200]}...")
            
            except Exception as e:
                logger.warning(f"Error parsing item in {team_url}: {str(e)}")
                continue
        
        logger.info(f"Extracted {len(persons_data)} persons from {team_url}")
        return persons_data
        
    except requests.RequestException as e:
        logger.error(f"Error extracting persons from {team_url}: {str(e)}")
        return []

def scrape():
    """Main function to scrape person data from UAEU Spotlights pages."""
    pages = [
        {"url": "https://www.uaeu.ac.ae/en/spotlights/index.shtml", "specialty": "Faculty"},
        {"url": "https://www.uaeu.ac.ae/en/spotlights/alumni_spotlight.shtml", "specialty": "Alumni"}
    ]
    logger.info("Starting UAEU Spotlights scraping process")
    
    # Initialize database connection
    db = Database()
    
    total_persons = 0
    for page in pages:
        logger.info(f"Scraping {page['url']} as {page['specialty']}")
        # Extract persons from the page
        persons = extract_doctors(page['url'], page['specialty'])
        
        if not persons:
            logger.warning(f"No persons found at {page['url']}. Continuing to next page.")
            continue
        
        # Insert persons into database
        for person in persons:
            db.insert_doctor(
                name=person['name'],
                specialty=person['specialty'],
                location=person['location'],
                profile_url=person['profile_url'],
                image_url=person['image_url'],
                source=person['source']
            )
            logger.debug(f"Added person: {person['name']} - {person['specialty']}")
            total_persons += 1
        
        time.sleep(2)  # Be polite to the server
    
    db.close()
    logger.info(f"UAEU Spotlights scraping completed. Total persons added: {total_persons}")