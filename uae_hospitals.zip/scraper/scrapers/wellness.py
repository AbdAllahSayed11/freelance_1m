import requests
from bs4 import BeautifulSoup
import time
import logging
from scraper.database import Database

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('wellness_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def extract_doctors(team_url):
    """Extract doctor information from the Wellness team page."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(team_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch team page {team_url}. Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        doctor_items = soup.select('.team-listing_item')
        
        doctors_data = []
        for item in doctor_items:
            # Extract name
            name_elem = item.select_one('.team-listing_name a')
            name = name_elem.text.strip() if name_elem else "N/A"
            
            # Extract specialty
            specialty_elem = item.select_one('.team-meta_item.position')
            specialty = specialty_elem.text.strip() if specialty_elem else "N/A"
            
            # Extract profile URL
            profile_link = item.select_one('.team-listing_name a') or item.select_one('.team-listing_photo a')
            profile_url = profile_link['href'] if profile_link and profile_link.get('href') else "N/A"
            
            # Extract image URL from data-lazy-src (for lazy-loaded images)
            img_elem = item.select_one('.team-listing_photo img')
            image_url = img_elem.get('data-lazy-src', 'N/A') if img_elem else "N/A"
            
            # Hardcoded location
            location = "Wellness One Day Surgery Center, Al Dhafrah"
            
            if name != "N/A":
                doctors_data.append({
                    'name': name,
                    'specialty': specialty,
                    'location': location,
                    'profile_url': profile_url,
                    'image_url': image_url,
                    'source': team_url
                })
            else:
                logger.warning(f"Skipping doctor with missing name at {team_url}. Item HTML: {str(item)[:200]}...")
            
        logger.info(f"Extracted {len(doctors_data)} doctors from {team_url}")
        return doctors_data
        
    except requests.RequestException as e:
        logger.error(f"Error extracting doctors from {team_url}: {str(e)}")
        return []

def scrape():
    """Main function to scrape doctor data from the Wellness team page."""
    team_url = "https://www.wellnesssurgerycenter.com/team/"
    logger.info("Starting Wellness One Day Surgery Center scraping process")
    
    # Initialize database connection
    db = Database()
    
    # Extract doctors from the team page
    doctors = extract_doctors(team_url)
    
    if not doctors:
        logger.error("No doctors found. Aborting scrape.")
        db.close()
        return
    
    total_doctors = 0
    # Insert doctors into database
    for doctor in doctors:
        db.insert_doctor(
            name=doctor['name'],
            specialty=doctor['specialty'],
            location=doctor['location'],
            profile_url=doctor['profile_url'],
            image_url=doctor['image_url'],
            source=doctor['source']
        )
        logger.debug(f"Added doctor: {doctor['name']} - {doctor['specialty']}")
        total_doctors += 1
    
    db.close()
    logger.info(f"Wellness One Day Surgery Center scraping completed. Total doctors added: {total_doctors}")