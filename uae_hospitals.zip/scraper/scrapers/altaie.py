import requests
from bs4 import BeautifulSoup
import time
import logging
import traceback
from scraper.database import Database
from urllib.parse import urljoin

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('altaie_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def extract_doctors(page_url):
    """Extract doctor information from an Al Taie Medical Center doctors page."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(page_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page {page_url}. Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        doctor_items = soup.select('div.bx')
        
        logger.debug(f"Found {len(doctor_items)} doctor items on {page_url}")
        
        doctors_data = []
        base_url = "https://altaiecenter.com"
        for item in doctor_items:
            try:
                # Extract name
                name_elem = item.select_one('.nm-txt h4')
                name = name_elem.text.strip() if name_elem else ""
                if not name or name == "N/A":
                    logger.warning(f"Skipping doctor with invalid name on {page_url}. Item HTML: {str(item)[:200]}...")
                    continue
                
                # Extract specialty
                spec_elem = item.select_one('.nm-txt p')
                specialty = spec_elem.text.strip() if spec_elem else ""
                if not specialty or specialty == "N/A":
                    logger.warning(f"Skipping doctor with invalid specialty on {page_url}. Item HTML: {str(item)[:200]}...")
                    continue
                
                # Extract profile URL
                profile_link = item.select_one('.nm-txt a')
                profile_url = urljoin(base_url, profile_link['href']) if profile_link and profile_link.get('href') else ""
                if not profile_url:
                    logger.warning(f"Skipping doctor with invalid profile URL on {page_url}. Item HTML: {str(item)[:200]}...")
                    continue
                
                # Extract image URL (prefer data-lazy-src, fallback to noscript img src)
                img_elem = item.select_one('img[data-lazy-src]')
                image_url = img_elem['data-lazy-src'] if img_elem and img_elem.get('data-lazy-src') else ""
                if not image_url:
                    noscript_img = item.select_one('noscript img')
                    image_url = noscript_img['src'] if noscript_img and noscript_img.get('src') else "N/A"
                
                # Format location
                location = "Al Taie Medical Center, Jumeirah, Dubai"
                
                doctor = {
                    'name': name,
                    'specialty': specialty,
                    'location': location,
                    'profile_url': profile_url,
                    'image_url': image_url,
                    'source': page_url
                }
                doctors_data.append(doctor)
                logger.debug(f"Extracted doctor: {name} - {specialty} - {profile_url}")
            
            except Exception as e:
                logger.warning(f"Error parsing doctor on {page_url}: {str(e)}. Item HTML: {str(item)[:200]}...")
                logger.debug(f"Stack trace: {traceback.format_exc()}")
                continue
        
        logger.info(f"Extracted {len(doctors_data)} valid doctors from {page_url}")
        return doctors_data
        
    except requests.RequestException as e:
        logger.error(f"Error fetching {page_url}: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
        return []
    except Exception as e:
        logger.error(f"Unexpected error in extract_doctors for {page_url}: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
        return []

def scrape():
    """Main function to scrape doctor data from Al Taie Medical Center Our Doctors pages."""
    base_url = "https://altaiecenter.com/our-doctors/"
    logger.info("Starting Al Taie Medical Center Our Doctors scraping process")
    
    # Initialize database connection
    db = None
    try:
        db = Database()
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
        return
    
    total_doctors = 0
    try:
        # Loop through pagination (pages 1 to 3)
        for page_num in range(1, 4):
            page_url = base_url if page_num == 1 else f"{base_url}page/{page_num}/"
            logger.info(f"Scraping page: {page_url}")
            
            doctors = extract_doctors(page_url)
            
            if not doctors:
                logger.warning(f"No valid doctors found on {page_url}.")
                if page_num > 1:
                    logger.info(f"Stopping pagination at page {page_num} due to no doctors found.")
                    break
            
            # Insert doctors into database
            for doctor in doctors:
                try:
                    db.insert_doctor(
                        name=doctor['name'],
                        specialty=doctor['specialty'],
                        location=doctor['location'],
                        profile_url=doctor['profile_url'],
                        image_url=doctor['image_url'],
                        source=doctor['source']
                    )
                    logger.debug(f"Added doctor to database: {doctor['name']} - {doctor['specialty']}")
                    total_doctors += 1
                except Exception as e:
                    logger.warning(f"Failed to insert doctor {doctor['name']} on {page_url}: {str(e)}")
                    logger.debug(f"Stack trace: {traceback.format_exc()}")
                    continue
            
            time.sleep(2)  # Be polite to the server
        
        logger.info(f"Al Taie Medical Center Our Doctors scraping completed. Total doctors added: {total_doctors}")
        
    except Exception as e:
        logger.error(f"Unexpected error during scraping: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
    finally:
        if db is not None:
            try:
                db.close()
            except Exception as e:
                logger.error(f"Error closing database: {str(e)}")
                logger.debug(f"Stack trace: {traceback.format_exc()}")