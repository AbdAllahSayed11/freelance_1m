import requests
from bs4 import BeautifulSoup
import time
import logging
import traceback
from scraper.database import Database
from urllib.parse import urljoin
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import random
import sqlite3
import re

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('hsmc_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def is_valid_doctor_name(name):
    """Validate if the name appears to be a doctor's name."""
    if not name or name == "N/A":
        return False
    # Check for common doctor prefixes or name-like patterns
    name = name.lower()
    if any(prefix in name for prefix in ['dr.', 'prof.', 'doctor', 'professor']):
        return True
    # Allow names with at least two words (e.g., "John Smith")
    if len(name.split()) >= 2 and not any(keyword in name for keyword in ['visit', 'quick links', 'opening hours', 'subscribe', 'we speak']):
        return True
    return False

def extract_doctors(page_url):
    """Extract doctor information from the Harley Street Medical Center doctors page."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    # Configure retries
    with requests.Session() as session:
        retries = Retry(
            total=5,
            backoff_factor=2,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"],
            raise_on_status=False
        )
        session.mount('https://', HTTPAdapter(max_retries=retries))
        
        base_timeout = 30
        for attempt in range(1, 6):
            try:
                timeout = base_timeout + (attempt - 1) * 10
                response = session.get(page_url, headers=headers, timeout=timeout)
                
                if response.status_code == 429:
                    sleep_time = 2 ** attempt + random.uniform(0.1, 0.5)
                    logger.warning(f"429 Too Many Requests for {page_url}. Sleeping {sleep_time:.2f}s before retry {attempt}/5")
                    time.sleep(sleep_time)
                    continue
                if response.status_code != 200:
                    logger.warning(f"Failed to fetch {page_url}. Status code: {response.status_code}")
                    return []
                
                # Parse HTML
                soup = BeautifulSoup(response.content, 'lxml')
                doctor_items = soup.select('div.rowItemContent:has(a.btBtn)')
                
                logger.debug(f"Found {len(doctor_items)} doctor items on {page_url}")
                
                doctors_data = []
                base_url = "https://www.hsmc.ae/"
                for item in doctor_items:
                    try:
                        # Extract name
                        name_elem = item.select_one('header.btClear h3')
                        name = name_elem.text.strip() if name_elem else ""
                        if not is_valid_doctor_name(name):
                            logger.warning(f"Skipping doctor with invalid name '{name}' on {page_url}. Item HTML: {str(item)[:200]}...")
                            continue
                        
                        # Extract specialty
                        specialty_elem = item.select_one('header.btClear div.btSubTitle')
                        specialty = "N/A"
                        if specialty_elem:
                            # Replace <br> with spaces
                            specialty_text = ' '.join(specialty_elem.get_text(separator=' ').split())
                            specialty = specialty_text.strip() if specialty_text.strip() else "N/A"
                        logger.debug(f"Specialty for {name}: {specialty}")
                        
                        # Extract profile URL
                        profile_link = item.select_one('a.btBtn')
                        profile_url = urljoin(base_url, profile_link['href']) if profile_link and profile_link.get('href') else ""
                        if not profile_url:
                            logger.warning(f"Skipping doctor with invalid profile URL for {name} on {page_url}. Item HTML: {str(item)[:200]}...")
                            continue
                        
                        # Extract image URL
                        img_elem = item.select_one('div.btImage img')
                        image_url = "N/A"
                        if img_elem:
                            data_src = img_elem.get('data-src', '')
                            logger.debug(f"Image attributes for {name}: data-src={data_src[:50]}")
                            if data_src and not data_src.startswith('data:image'):
                                if data_src.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')):
                                    image_url = urljoin(base_url, data_src)
                                else:
                                    logger.warning(f"Invalid image extension for {name} on {page_url}. Data-src: {data_src[:50]}... Img HTML: {str(img_elem)[:200]}...")
                            else:
                                logger.warning(f"No valid image source for {name} on {page_url}. Data-src: {data_src[:50]}... Img HTML: {str(img_elem)[:200]}...")
                        else:
                            logger.warning(f"No image element found for {name} on {page_url}. Item HTML: {str(item)[:200]}...")
                        
                        # Format doctor data
                        doctor = {
                            'name': name,
                            'specialty': specialty,
                            'location': "Harley Street Medical Center",
                            'profile_url': profile_url,
                            'image_url': image_url,
                            'source': page_url
                        }
                        doctors_data.append(doctor)
                        logger.debug(f"Extracted doctor: {name} - {specialty} - {profile_url} - {image_url}")
                    
                    except Exception as e:
                        logger.warning(f"Error parsing doctor on {page_url}: {str(e)}. Item HTML: {str(item)[:200]}...")
                        logger.debug(f"Stack trace: {traceback.format_exc()}")
                        continue
                
                logger.info(f"Extracted {len(doctors_data)} valid doctors from {page_url}")
                
                # Check for pagination
                try:
                    next_page = soup.select_one('a.next, a.load-more, a.pagination-link')
                    if next_page:
                        logger.warning(f"Pagination detected at {page_url}, but not implemented. Please provide pagination URLs if needed.")
                except Exception:
                    pass
                
                return doctors_data
            
            except (requests.RequestException, ConnectionError, TimeoutError) as e:
                logger.warning(f"Attempt {attempt}/5 failed for {page_url}: {str(e)}")
                if attempt == 5:
                    logger.error(f"Max retries reached for {page_url}: {str(e)}")
                    logger.debug(f"Stack trace: {traceback.format_exc()}")
                    return []
                time.sleep(2 + random.uniform(0.1, 0.5))  # Retry delay with jitter
            except Exception as e:
                logger.error(f"Unexpected error fetching {page_url}: {str(e)}")
                logger.debug(f"Stack trace: {traceback.format_exc()}")
                return []

def scrape():
    """Main function to scrape doctor data from Harley Street Medical Center doctors page."""
    base_url = "https://www.hsmc.ae/our-doctors/"
    logger.info("Starting Harley Street Medical Center doctor scraping process")
    
    # Initialize database connection
    db = None
    try:
        db = Database()
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
        return
    
    total_doctors = 0
    try:
        # Process the main page
        logger.info(f"Scraping page: {base_url}")
        
        doctors = extract_doctors(base_url)
        
        if not doctors:
            logger.warning(f"No valid doctors found on {base_url}.")
        
        # Insert doctors into database
        for doctor in doctors:
            for attempt in range(1, 3):
                try:
                    # Validate required fields
                    required_fields = ['name', 'specialty', 'location', 'profile_url', 'image_url', 'source']
                    missing_fields = [field for field in required_fields if field not in doctor or not doctor[field]]
                    if missing_fields:
                        logger.warning(f"Skipping insertion for {doctor.get('name', 'Unknown')} due to missing fields: {missing_fields}. Doctor data: {doctor}")
                        break
                    
                    db.insert_doctor(
                        name=doctor['name'],
                        specialty=doctor['specialty'],
                        location=doctor['location'],
                        profile_url=doctor['profile_url'],
                        image_url=doctor['image_url'],
                        source=doctor['source']
                    )
                    logger.debug(f"Added doctor to database: {doctor['name']} - {doctor['specialty']} - {doctor['image_url']}")
                    total_doctors += 1
                    break
                except sqlite3.OperationalError as e:
                    if attempt == 2:
                        logger.warning(f"Failed to insert doctor {doctor.get('name', 'Unknown')} for {base_url} after retries: {str(e)}. Doctor data: {doctor}")
                        logger.debug(f"Stack trace: {traceback.format_exc()}")
                        break
                    logger.warning(f"Database error for {doctor.get('name', 'Unknown')} (attempt {attempt}/2): {str(e)}. Retrying...")
                    time.sleep(0.5 + random.uniform(0.1, 0.2))
                except Exception as e:
                    logger.warning(f"Failed to insert doctor {doctor.get('name', 'Unknown')} for {base_url}: {str(e)}. Doctor data: {doctor}")
                    logger.debug(f"Stack trace: {traceback.format_exc()}")
                    break
        
        logger.info(f"Harley Street Medical Center doctor scraping completed. Total doctors added: {total_doctors}")
        
    except Exception as e:
        logger.error(f"Unexpected error during scraping: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
    finally:
        if db is not None:
            try:
                db.close()
            except Exception as e:
                logger.error(f"Error closing database: {str(e)}")
                logger.debug(f"Stack trace: {traceback.format_exc()}")