import requests
from bs4 import BeautifulSoup
import time
import logging
import traceback
from scraper.database import Database
from urllib.parse import urljoin
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import random
import sqlite3
import re

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('livhospital_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def extract_doctors(page_url):
    """Extract doctor information from the Liv Hospital doctors page."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    # Configure retries
    with requests.Session() as session:
        retries = Retry(
            total=5,
            backoff_factor=2,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"],
            raise_on_status=False
        )
        session.mount('https://', HTTPAdapter(max_retries=retries))
        
        base_timeout = 30
        for attempt in range(1, 6):
            try:
                timeout = base_timeout + (attempt - 1) * 10
                response = session.get(page_url, headers=headers, timeout=timeout)
                
                if response.status_code == 429:
                    sleep_time = 2 ** attempt + random.uniform(0.1, 0.5)
                    logger.warning(f"429 Too Many Requests for {page_url}. Sleeping {sleep_time:.2f}s before retry {attempt}/5")
                    time.sleep(sleep_time)
                    continue
                if response.status_code != 200:
                    logger.warning(f"Failed to fetch {page_url}. Status code: {response.status_code}")
                    return []
                
                # Parse HTML
                soup = BeautifulSoup(response.content, 'lxml')
                doctor_items = soup.select('div.tdm-team-member-wrap')
                
                logger.debug(f"Found {len(doctor_items)} doctor items on {page_url}")
                
                doctors_data = []
                base_url = "https://www.livhospital.ae/"
                for item in doctor_items:
                    try:
                        # Extract name
                        name_elem = item.select_one('h3.tdm-title a')
                        name = name_elem.text.strip() if name_elem else ""
                        if not name or name == "N/A":
                            logger.warning(f"Skipping doctor with invalid name on {page_url}. Item HTML: {str(item)[:200]}...")
                            continue
                        
                        # Extract profile URL
                        profile_url = urljoin(base_url, name_elem['href']) if name_elem and name_elem.get('href') else ""
                        if not profile_url:
                            logger.warning(f"Skipping doctor with invalid profile URL for {name} on {page_url}. Item HTML: {str(item)[:200]}...")
                            continue
                        
                        # Extract specialty
                        specialty_elem = item.select_one('div.tdm-member-info-inner p.tdm-descr')
                        specialty = specialty_elem.text.strip() if specialty_elem and specialty_elem.text.strip() else "N/A"
                        
                        # Extract image URL
                        img_elem = item.select_one('div.tdm-member-image')
                        image_url = "N/A"
                        if img_elem and img_elem.get('style'):
                            style = img_elem['style']
                            logger.debug(f"Image style for {name}: {style[:100]}")
                            match = re.search(r'background-image:\s*url\((.*?)\)', style)
                            if match:
                                src = match.group(1).strip('\'"')
                                if src and not src.startswith('data:image'):
                                    if src.lower().endswith(('.jpg', '.jpeg', '.png')):
                                        image_url = urljoin(base_url, src)
                                    else:
                                        logger.warning(f"Invalid image extension for {name} on {page_url}. Src: {src[:50]}... Style: {style[:100]}...")
                                else:
                                    logger.warning(f"No valid image source for {name} on {page_url}. Src: {src[:50]}... Style: {style[:100]}...")
                            else:
                                logger.warning(f"No background-image found for {name} on {page_url}. Style: {style[:100]}...")
                        else:
                            logger.warning(f"No image element or style found for {name} on {page_url}. Item HTML: {str(item)[:200]}...")
                        
                        # Format doctor data
                        doctor = {
                            'name': name,
                            'specialty': specialty,
                            'location': "Liv Hospital City Walk",
                            'profile_url': profile_url,
                            'image_url': image_url,
                            'source': page_url
                        }
                        doctors_data.append(doctor)
                        logger.debug(f"Extracted doctor: {name} - {specialty} - {profile_url} - {image_url}")
                    
                    except Exception as e:
                        logger.warning(f"Error parsing doctor on {page_url}: {str(e)}. Item HTML: {str(item)[:200]}...")
                        logger.debug(f"Stack trace: {traceback.format_exc()}")
                        continue
                
                logger.info(f"Extracted {len(doctors_data)} valid doctors from {page_url}")
                
                # Check for pagination
                try:
                    next_page = soup.select_one('a.next, a.load-more, a.pagination-link')
                    if next_page:
                        logger.warning(f"Pagination detected at {page_url}, but not implemented. Please provide pagination URLs if needed.")
                except Exception:
                    pass
                
                return doctors_data
            
            except (requests.RequestException, ConnectionError, TimeoutError) as e:
                logger.warning(f"Attempt {attempt}/5 failed for {page_url}: {str(e)}")
                if attempt == 5:
                    logger.error(f"Max retries reached for {page_url}: {str(e)}")
                    logger.debug(f"Stack trace: {traceback.format_exc()}")
                    return []
                time.sleep(2 + random.uniform(0.1, 0.5))  # Retry delay with jitter
            except Exception as e:
                logger.error(f"Unexpected error fetching {page_url}: {str(e)}")
                logger.debug(f"Stack trace: {traceback.format_exc()}")
                return []

def scrape():
    """Main function to scrape doctor data from Liv Hospital doctors page."""
    base_url = "https://www.livhospital.ae/doctors/"
    logger.info("Starting Liv Hospital City Walk doctor scraping process")
    
    # Initialize database connection
    db = None
    try:
        db = Database()
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
        return
    
    total_doctors = 0
    try:
        # Process the main page
        logger.info(f"Scraping page: {base_url}")
        
        doctors = extract_doctors(base_url)
        
        if not doctors:
            logger.warning(f"No valid doctors found on {base_url}.")
        
        # Insert doctors into database
        for doctor in doctors:
            for attempt in range(1, 3):
                try:
                    # Validate required fields
                    required_fields = ['name', 'specialty', 'location', 'profile_url', 'image_url', 'source']
                    missing_fields = [field for field in required_fields if field not in doctor or not doctor[field]]
                    if missing_fields:
                        logger.warning(f"Skipping insertion for {doctor.get('name', 'Unknown')} due to missing fields: {missing_fields}. Doctor data: {doctor}")
                        break
                    
                    db.insert_doctor(
                        name=doctor['name'],
                        specialty=doctor['specialty'],
                        location=doctor['location'],
                        profile_url=doctor['profile_url'],
                        image_url=doctor['image_url'],
                        source=doctor['source']
                    )
                    logger.debug(f"Added doctor to database: {doctor['name']} - {doctor['specialty']} - {doctor['image_url']}")
                    total_doctors += 1
                    break
                except sqlite3.OperationalError as e:
                    if attempt == 2:
                        logger.warning(f"Failed to insert doctor {doctor.get('name', 'Unknown')} for {base_url} after retries: {str(e)}. Doctor data: {doctor}")
                        logger.debug(f"Stack trace: {traceback.format_exc()}")
                        break
                    logger.warning(f"Database error for {doctor.get('name', 'Unknown')} (attempt {attempt}/2): {str(e)}. Retrying...")
                    time.sleep(0.5 + random.uniform(0.1, 0.2))
                except Exception as e:
                    logger.warning(f"Failed to insert doctor {doctor.get('name', 'Unknown')} for {base_url}: {str(e)}. Doctor data: {doctor}")
                    logger.debug(f"Stack trace: {traceback.format_exc()}")
                    break
        
        logger.info(f"Liv Hospital City Walk doctor scraping completed. Total doctors added: {total_doctors}")
        
    except Exception as e:
        logger.error(f"Unexpected error during scraping: {str(e)}")
        logger.debug(f"Stack trace: {traceback.format_exc()}")
    finally:
        if db is not None:
            try:
                db.close()
            except Exception as e:
                logger.error(f"Error closing database: {str(e)}")
                logger.debug(f"Stack trace: {traceback.format_exc()}")