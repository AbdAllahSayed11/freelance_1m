import requests
from bs4 import BeautifulSoup
import time
import logging
from scraper.database import Database
from urllib.parse import urljoin

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('skmc_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def extract_doctors(clinic_id, clinic_name, base_url):
    """Extract doctor information from a SKMC clinic POST response."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    data = {
        "specialt": clinic_id,
        "doclst": "",
        "searchbtn": "Search"
    }
    
    try:
        response = requests.post(base_url, headers=headers, data=data, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch doctors for clinic ID {clinic_id} ({clinic_name}). Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        doc_list = soup.select('.doclist .doctorsec')
        
        doctors_data = []
        for item in doc_list:
            try:
                # Extract name
                name_elem = item.select_one('.docname')
                name = name_elem.text.strip() if name_elem else "N/A"
                
                # Extract specialty (handle multiple .spec tags, take first non-empty)
                spec_elems = item.select('.spec')
                specialty = "N/A"
                for spec_elem in spec_elems:
                    spec_text = spec_elem.text.strip().rstrip(',')
                    if spec_text:
                        specialty = spec_text
                        break
                if specialty == "N/A":
                    logger.warning(f"No valid specialty found for doctor in clinic {clinic_name}. Item HTML: {str(item)[:200]}...")
                
                # Extract profile URL
                profile_link = item.select_one('a')
                profile_url = urljoin(base_url, profile_link['href']) if profile_link and profile_link.get('href') else "N/A"
                
                # Extract image URL
                img_elem = item.select_one('.featimg img')
                image_url = urljoin(base_url, img_elem['src']) if img_elem and img_elem.get('src') else "N/A"
                
                # Format location
                location = f"Sheikh Khalifa Medical City (SKMC) Hospital, Al Markaziyah, {clinic_name}"
                
                if name != "N/A":
                    doctors_data.append({
                        'name': name,
                        'specialty': specialty,
                        'location': location,
                        'profile_url': profile_url,
                        'image_url': image_url,
                        'source': base_url
                    })
                else:
                    logger.warning(f"Skipping doctor with missing name for clinic {clinic_name}. Item HTML: {str(item)[:200]}...")
            
            except Exception as e:
                logger.warning(f"Error parsing doctor in clinic {clinic_name}: {str(e)}")
                continue
        
        logger.info(f"Extracted {len(doctors_data)} doctors from clinic {clinic_name}")
        return doctors_data
        
    except requests.RequestException as e:
        logger.error(f"Error extracting doctors for clinic ID {clinic_id} ({clinic_name}): {str(e)}")
        return []

def scrape():
    """Main function to scrape doctor data from SKMC Our Doctors page."""
    base_url = "https://www.skmca.ae/our-doctors/"
    logger.info("Starting SKMC Our Doctors scraping process")
    
    # Fetch the initial page to get clinic IDs
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(base_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page {base_url}. Status code: {response.status_code}")
            return
        
        soup = BeautifulSoup(response.content, 'html.parser')
        clinic_select = soup.select_one('select[name="specialt"]')
        if not clinic_select:
            logger.error("No clinic dropdown found on the page.")
            return
        
        clinics = []
        for option in clinic_select.find_all('option'):
            clinic_id = option.get('value')
            clinic_name = option.text.strip()
            if clinic_id and clinic_id != "select" and clinic_name:
                clinics.append({"id": clinic_id, "name": clinic_name})
        
        if not clinics:
            logger.error("No valid clinics found in the dropdown.")
            return
        
        logger.info(f"Found {len(clinics)} clinics to scrape")
        
        # Initialize database connection
        db = Database()
        
        total_doctors = 0
        for clinic in clinics:
            logger.info(f"Scraping clinic: {clinic['name']} (ID: {clinic['id']})")
            doctors = extract_doctors(clinic['id'], clinic['name'], base_url)
            
            if not doctors:
                logger.warning(f"No doctors found for clinic {clinic['name']}.")
                continue
            
            # Insert doctors into database
            for doctor in doctors:
                db.insert_doctor(
                    name=doctor['name'],
                    specialty=doctor['specialty'],
                    location=doctor['location'],
                    profile_url=doctor['profile_url'],
                    image_url=doctor['image_url'],
                    source=doctor['source']
                )
                logger.debug(f"Added doctor: {doctor['name']} - {doctor['specialty']}")
                total_doctors += 1
            
            time.sleep(2)  # Be polite to the server
        
        db.close()
        logger.info(f"SKMC Our Doctors scraping completed. Total doctors added: {total_doctors}")
        
    except requests.RequestException as e:
        logger.error(f"Error fetching initial page {base_url}: {str(e)}")
        if 'db' in locals():
            db.close()
    except Exception as e:
        logger.error(f"Unexpected error during scraping: {str(e)}")
        if 'db' in locals():
            db.close()