import os
import sys
import sqlite3
import logging
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QListWidget, QPushButton, QTextEdit, 
                            QListWidgetItem, QProgressBar)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QColor, QPalette
from scraper.database import Database
from scraper.scrapers import fakeeh,ksmc,jhah,imc,ksu,kkesh,kau,iau,kabh,kkht

SCRAPERS = {
    "fakeeh.care": fakeeh.scrape,
    "ksmc.med.sa": ksmc.scrape,
    "jhah.com": jhah.scrape,
    "imc.med.sa": imc.scrape,
    "ksu.edu.sa": ksu.scrape,
    "kkesh.med.sa": kkesh.scrape,
    "hospital.kau.edu.sa": kau.scrape,
    "iau.edu.sa": iau.scrape,
    "kabh.med.sa": kabh.scrape,
    "kkht.med.sa": kkht.scrape,
}

class QtLogHandler(logging.Handler):
    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget

    def emit(self, record):
        msg = self.format(record)
        self.text_widget.append(msg)

class ScraperWorker(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    
    def __init__(self, domain, scrape_func):
        super().__init__()
        self.domain = domain
        self.scrape_func = scrape_func
        self.is_running = True
    
    def run(self):
        try:
            self.log_signal.emit(f"[*] بدء استخراج البيانات لـ {self.domain}")
            self.progress_signal.emit(0)
            
            import inspect
            sig = inspect.signature(self.scrape_func)
            has_callback = len(sig.parameters) > 0
            
            if has_callback:
                def progress_callback(progress):
                    if self.is_running:
                        self.progress_signal.emit(progress)
                        self.log_signal.emit(f"[>] تقدم {self.domain}: {progress}%")
                self.scrape_func(progress_callback)
            else:
                self.scrape_func()
                self.progress_signal.emit(100)
            
            if self.is_running:
                self.log_signal.emit(f"[+] اكتمل استخراج بيانات {self.domain} بنجاح")
        except Exception as e:
            if self.is_running:
                self.log_signal.emit(f"[!] خطأ في استخراج بيانات {self.domain}: {str(e)}")
                self.progress_signal.emit(0)
    
    def stop(self):
        self.is_running = False

class SaudiScraperGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("مستخرج البيانات السعودي  | By A.S & Abdallah")
        self.setGeometry(100, 100, 1000, 800)
        
        self.set_saudi_theme()
        
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        
        self.scraper_list = QListWidget()
        self.scraper_list.setFont(QFont("Tajawal", 12))
        for domain in SCRAPERS.keys():
            item = QListWidgetItem(domain)
            item.setForeground(QColor("#FFFFFF"))
            self.scraper_list.addItem(item)
        self.scraper_list.setStyleSheet("background-color: #1A3C34; border: 2px solid #FFFFFF; color: #FFFFFF;")
        layout.addWidget(self.scraper_list)
        
        button_layout = QHBoxLayout()
        
        self.start_button = QPushButton("استخراج الأهداف المحددة")
        self.start_button.clicked.connect(self.start_selected)
        self.start_button.setFont(QFont("Tajawal", 12))
        self.start_button.setStyleSheet(
            "QPushButton {background-color: #006C35; color: #FFFFFF; border: 2px solid #FFFFFF; padding: 5px;} "
            "QPushButton:disabled {background-color: #4A4A4A; color: #808080; border: 2px solid #808080;}"
        )
        button_layout.addWidget(self.start_button)
        
        self.start_all_button = QPushButton("استخراج جميع الأنظمة")
        self.start_all_button.clicked.connect(self.start_all)
        self.start_all_button.setFont(QFont("Tajawal", 12))
        self.start_all_button.setStyleSheet(
            "QPushButton {background-color: #006C35; color: #FFFFFF; border: 2px solid #FFFFFF; padding: 5px;} "
            "QPushButton:disabled {background-color: #4A4A4A; color: #808080; border: 2px solid #808080;}"
        )
        button_layout.addWidget(self.start_all_button)
        
        layout.addLayout(button_layout)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet(
            "QProgressBar {background-color: #1A3C34; border: 2px solid #FFFFFF; color: #FFFFFF;} "
            "QProgressBar::chunk {background-color: #006C35;}"
        )
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("تقدم الاستخراج: %p%")
        layout.addWidget(self.progress_bar)
        
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Tajawal", 10))
        self.console.setStyleSheet("background-color: #0A1F1A; color: #FFFFFF; border: 2px solid #FFFFFF; padding: 5px;")
        layout.addWidget(self.console)
        
        self.log_handler = QtLogHandler(self.console)
        self.log_handler.setFormatter(logging.Formatter(
            '[%(asctime)s] [%(levelname)s] %(message)s', 
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        logger = logging.getLogger()
        logger.addHandler(self.log_handler)
        logger.setLevel(logging.INFO)
        
        sys.stdout = Stream(self.console)
        
        self.workers = {}
        self.progress_values = {}
        
    def set_saudi_theme(self):
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor("#0A1F1A"))
        palette.setColor(QPalette.WindowText, QColor("#FFFFFF"))
        palette.setColor(QPalette.Base, QColor("#1A3C34"))
        palette.setColor(QPalette.AlternateBase, QColor("#2A5A4A"))
        palette.setColor(QPalette.Text, QColor("#FFFFFF"))
        palette.setColor(QPalette.Button, QColor("#006C35"))
        palette.setColor(QPalette.ButtonText, QColor("#FFFFFF"))
        palette.setColor(QPalette.BrightText, QColor("#E6F3E6"))
        self.setPalette(palette)
        self.setStyleSheet("QMainWindow { background-color: #0A1F1A; }")
        
    def log_message(self, message):
        self.console.append(message)
        
    def update_progress(self, value):
        sender = self.sender()
        if sender and hasattr(sender, 'domain'):
            self.progress_values[sender.domain] = value
            total_progress = sum(self.progress_values.values()) / len(self.workers) if self.workers else 0
            self.progress_bar.setValue(int(total_progress))
        
    def start_selected(self):
        selected_items = self.scraper_list.selectedItems()
        if not selected_items:
            self.log_message("[!] لم يتم اختيار أي أهداف!")
            return
            
        for item in selected_items:
            domain = item.text()
            if domain not in self.workers:
                self.start_scraper(domain)
            else:
                self.log_message(f"[*] {domain} قيد الاستخراج بالفعل")
        
        if self.workers:
            self.toggle_buttons(True)
            
    def start_all(self):
        for domain in SCRAPERS.keys():
            if domain not in self.workers:
                self.start_scraper(domain)
            else:
                self.log_message(f"[*] {domain} قيد الاستخراج بالفعل")
                
        if self.workers:
            self.toggle_buttons(True)
            
    def start_scraper(self, domain):
        if domain in SCRAPERS:
            worker = ScraperWorker(domain, SCRAPERS[domain])
            worker.log_signal.connect(self.log_message)
            worker.progress_signal.connect(self.update_progress)
            worker.finished.connect(lambda: self.worker_finished(domain))
            self.workers[domain] = worker
            self.progress_values[domain] = 0
            worker.start()
        else:
            self.log_message(f"[!] لا يوجد مستخرج متاح لـ {domain}")
            
    def worker_finished(self, domain):
        if domain in self.workers:
            del self.workers[domain]
            del self.progress_values[domain]
        if not self.workers:
            self.toggle_buttons(False)
            self.progress_bar.setValue(100)
            self.log_message("[+] اكتملت جميع عمليات الاستخراج")
        else:
            total_progress = sum(self.progress_values.values()) / len(self.workers) if self.workers else 0
            self.progress_bar.setValue(int(total_progress))
            
    def toggle_buttons(self, running):
        self.start_button.setEnabled(not running)
        self.start_all_button.setEnabled(not running)

class Stream:
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, text):
        self.text_widget.append(text.strip())

    def flush(self):
        pass

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SaudiScraperGUI()
    window.show()
    sys.exit(app.exec_())