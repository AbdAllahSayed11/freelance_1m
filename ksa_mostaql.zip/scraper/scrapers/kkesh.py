import requests
import json
import logging
from time import sleep
from scraper.database import Database

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('kkesh_scraper.log', mode='w'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def fetch_doctors(page_number=1, page_size=100):
    url = "https://extapi.kkesh.med.sa/api/AUDoctors/GetDoctorsFilter"
    headers = {
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0",
        "Host": "extapi.kkesh.med.sa",
        "Content-Type": "application/json"
    }
    payload = {
        "searchKey": "",
        "pageSize": page_size,
        "pageNumber": page_number,
        "doctorType": "",
        "doctorSpecialization": ""
    }

    try:
        logger.info(f"Sending POST request to {url} (Page {page_number}, Size {page_size})")
        response = requests.post(url, headers=headers, json=payload, timeout=60)
        if response.status_code != 200:
            logger.error(f"Failed to fetch data. Status code: {response.status_code}")
            return None, 0

        data = response.json()
        if not data.get("isSuccess", False):
            logger.error(f"API returned unsuccessful response: {data.get('description', 'No description')}")
            return None, 0

        doctors = data.get("data", {}).get("items", [])
        total_count = data.get("data", {}).get("totalCount", 0)
        logger.info(f"Fetched {len(doctors)} doctors on page {page_number} (API reports total: {total_count})")
        return doctors, total_count

    except requests.RequestException as e:
        logger.error(f"Error fetching data from API: {str(e)}", exc_info=True)
        return None, 0
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse JSON response: {str(e)}", exc_info=True)
        return None, 0

def extract_doctor_data(doctor):
    try:
        name_ar = doctor.get("titleAr", "N/A").strip()
        name_en = doctor.get("titleEn", "N/A").strip()
        name = name_ar if name_ar != "N/A" else name_en

        specialty = doctor.get("doctorSpecializationAr", "N/A").strip()
        if specialty == "N/A":
            specialty = doctor.get("doctorSpecializationEn", "N/A").strip()

        image_url = "N/A"
        images_cache = doctor.get("imagesCache")
        if images_cache and images_cache.get("thumb"):
            image_url = images_cache["thumb"].get("imageData", "N/A")

        profile_url = f"https://kkesh.med.sa/kkesh-doctors/{doctor.get('id')}"

        if name == "N/A":
            logger.warning(f"Skipping doctor with missing name: {doctor.get('id')}")
            return None

        doctor_data = {
            "name": name,
            "specialty": specialty,
            "image_url": image_url,
            "profile_url": profile_url,
            "source": "kkesh.med.sa"
        }
        logger.debug(f"Extracted doctor data: {doctor_data}")
        return doctor_data

    except Exception as e:
        logger.error(f"Error extracting doctor data for ID {doctor.get('id', 'unknown')}: {str(e)}", exc_info=True)
        return None

def scrape():
    logger.info("Starting King Khaled Eye Specialist Hospital scraping process")

    db = Database()
    total_doctors = 0
    page_number = 1
    page_size = 100
    all_doctors = []

    while True:
        doctors, total_count = fetch_doctors(page_number, page_size)
        if doctors is None:
            logger.warning("Failed to fetch doctors. Exiting pagination loop.")
            break

        all_doctors.extend(doctors)
        logger.info(f"Collected {len(all_doctors)} doctors so far")

        if len(all_doctors) >= total_count or not doctors:
            break

        page_number += 1
        sleep(1)

    if not all_doctors:
        logger.warning("No doctors fetched. Exiting.")
        db.close()
        return

    for doctor in all_doctors:
        doctor_data = extract_doctor_data(doctor)
        if not doctor_data:
            continue

        try:
            logger.debug(f"Attempting to insert doctor: {doctor_data}")
            db.insert_doctor(
                name=doctor_data["name"],
                specialty=doctor_data["specialty"],
                location="مستشفى الملك خالد التخصصي للعيون",
                profile_url=doctor_data["profile_url"],
                image_url=doctor_data["image_url"],
                source=doctor_data["source"]
            )
            total_doctors += 1
            logger.info(f"Added doctor: {doctor_data['name']} - {doctor_data['specialty']} (Total: {total_doctors})")
        except Exception as e:
            logger.error(f"Failed to insert doctor '{doctor_data['name']}': {str(e)}", exc_info=True)

    db.close()
    logger.info(f"KKESH scraping completed. Total doctors added: {total_doctors}")