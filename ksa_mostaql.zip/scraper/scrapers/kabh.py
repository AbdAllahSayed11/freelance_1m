import requests
import logging
from bs4 import BeautifulSoup
from scraper.database import Database

# Configure logging to file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('kabh_scraper.log', mode='w'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def fetch_page():
    """Fetch the HTML content from the target POST API endpoint."""
    url = "https://care.med.sa/en/appiontment/ourdoctors"
    headers = {
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0",
        "Host": "care.med.sa",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
    }
    # Minimal payload to trigger the POST request; adjust if specific data is required
    data = {}

    try:
        logger.info(f"Sending POST request to {url}")
        response = requests.post(url, headers=headers, data=data, timeout=60)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page. Status code: {response.status_code}")
            return None

        logger.info("Successfully fetched page")
        return response.text

    except requests.RequestException as e:
        logger.error(f"Error fetching page from {url}: {str(e)}", exc_info=True)
        return None

def extract_doctor_data(html):
    """Extract doctor data from the HTML content."""
    if not html:
        return []

    # Use html5lib parser for robust handling of HTML
    try:
        soup = BeautifulSoup(html, 'html5lib')
    except ValueError as e:
        if 'html5lib' in str(e):
            logger.error("The html5lib parser is required but not installed. Install it with 'pip install html5lib'.")
            logger.warning("Falling back to html.parser, which may lead to incomplete parsing.")
            soup = BeautifulSoup(html, 'html.parser')
        else:
            logger.error(f"Error creating BeautifulSoup object: {str(e)}")
            return []

    # Find all doctor cards within the row
    doctor_cards = soup.select('div.row div.col-md-4')
    if not doctor_cards:
        logger.error("No doctor cards found in the HTML")
        logger.debug(f"HTML snippet: {html[:1000]}")  # Log first 1000 chars for debugging
        return []

    doctors = []
    seen_doctors = set()  # To handle duplicates based on name and specialty
    for card in doctor_cards:
        link = card.find('a')
        if not link:
            logger.warning("Skipping card with no link")
            continue

        profile_url = f"https://care.med.sa{link['href']}" if link.get('href') else "N/A"

        card_content = link.find('div', class_='card')
        if not card_content:
            logger.warning("Skipping card with no content")
            continue

        # Extract data
        name_elem = card_content.find('h4')
        name = name_elem.get_text(strip=True) if name_elem else None

        specialty_elem = card_content.find('p', class_='title')
        specialty = specialty_elem.get_text(strip=True) if specialty_elem else "N/A"

        # Skip if name is missing
        if not name:
            logger.warning("Skipping card with missing name")
            continue

        # Handle duplicates
        doctor_key = (name, specialty)
        if doctor_key in seen_doctors:
            logger.debug(f"Skipping duplicate doctor: {name} - {specialty}")
            continue
        seen_doctors.add(doctor_key)

        image_elem = card_content.find('img', class_='img-render')
        image_url = image_elem.get('data-src') if image_elem and image_elem.get('data-src') else "N/A"

        location_elem = card_content.find_all('p')[-1]  # Last <p> is location
        location = location_elem.get_text(strip=True) if location_elem else "مستشفى الملك عبدالله"

        doctor_data = {
            "name": name,
            "specialty": specialty,
            "profile_url": profile_url,
            "source": "https://care.med.sa/en/appiontment/ourdoctors",
            "location": location,
            "image_url": image_url
        }
        logger.debug(f"Extracted doctor data: {doctor_data}")
        doctors.append(doctor_data)

    logger.info(f"Extracted {len(doctors)} unique doctors from the page")
    return doctors

def scrape():
    """Main function to scrape doctor data and store it in the database."""
    logger.info("Starting King Abdullah Hospital scraping process")

    db = Database()
    total_doctors = 0

    html = fetch_page()
    if not html:
        logger.warning("No HTML content fetched. Exiting.")
        db.close()
        return

    doctors = extract_doctor_data(html)
    if not doctors:
        logger.warning("No doctors extracted from the page. Exiting.")
        db.close()
        return

    for doctor_data in doctors:
        try:
            logger.debug(f"Attempting to insert doctor: {doctor_data}")
            db.insert_doctor(
                name=doctor_data["name"],
                specialty=doctor_data["specialty"],
                location=doctor_data["location"],
                profile_url=doctor_data["profile_url"],
                image_url=doctor_data["image_url"],
                source=doctor_data["source"]
            )
            total_doctors += 1
            logger.info(f"Added doctor: {doctor_data['name']} - {doctor_data['specialty']} (Total: {total_doctors})")
        except Exception as e:
            logger.error(f"Failed to insert doctor '{doctor_data['name']}': {str(e)}", exc_info=True)

    db.close()
    logger.info(f"KABH scraping completed. Total doctors added: {total_doctors}")
