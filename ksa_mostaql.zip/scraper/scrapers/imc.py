# imc.py
import requests
from requests.structures import CaseInsensitiveDict
import logging
from bs4 import BeautifulSoup
from time import sleep
from scraper.database import Database

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('imc_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def scrape():
    """Scrape doctor data from imc.med.sa across multiple pages and store it in the database."""
    logger.info("Starting IMC scraping process")

    base_url = "https://www.imc.med.sa/en/doctorsearch?&page="
    headers = CaseInsensitiveDict()
    headers["Host"] = "www.imc.med.sa"
    headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
    headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
    headers["Accept-Encoding"] = "gzip, deflate, br"

    session = requests.Session()
    adapter = requests.adapters.HTTPAdapter(max_retries=3)
    session.mount("https://", adapter)

    db = Database()
    total_doctors = 0

    # Loop through pages 1 to 25
    for page in range(1, 26):
        url = f"{base_url}{page}"
        logger.info(f"Fetching page {page}: {url}")

        try:
            response = session.get(url, headers=headers, timeout=60)
            if response.status_code != 200:
                logger.error(f"Failed to fetch page {page}. Status code: {response.status_code}")
                continue
            soup = BeautifulSoup(response.text, 'html.parser')
        except requests.RequestException as e:
            logger.error(f"Error fetching page {page}: {str(e)}")
            continue

        # Find all doctor profiles
        doctor_profiles = soup.select("div.doctor-profile")
        if not doctor_profiles:
            logger.warning(f"No doctor profiles found on page {page}")
            continue

        logger.info(f"Found {len(doctor_profiles)} doctor profiles on page {page}")

        # Process each doctor profile
        for profile in doctor_profiles:
            # Extract name
            name_tag = profile.select_one("p.d-name a")
            name = name_tag.get_text(strip=True) if name_tag else "N/A"

            # Extract specialty
            specialty_tag = profile.select_one("p.specail-in")
            specialty = specialty_tag.get_text(strip=True) if specialty_tag else "N/A"

            # Extract profile URL
            profile_url_tag = profile.select_one("a.view-profile")
            profile_url = profile_url_tag['href'] if profile_url_tag else "N/A"

            # Extract image URL
            image_tag = profile.select_one("div.dctr-img img")
            image_url = image_tag['src'] if image_tag else "N/A"

            if name == "N/A":
                logger.debug("Skipping doctor with missing name")
                continue

            # Insert into database
            try:
                db.insert_doctor(
                    name=name,
                    specialty=specialty,
                    location="N/A",  # Location not available in provided HTML
                    profile_url=profile_url,
                    image_url=image_url,
                    source="imc.med.sa"
                )
                logger.debug(f"Added doctor: {name} - {specialty}")
                total_doctors += 1
            except Exception as e:
                logger.error(f"Failed to insert doctor {name}: {str(e)}")
                continue

        sleep(1)  # Delay between pages to avoid rate-limiting

    db.close()
    logger.info(f"IMC scraping completed. Total doctors added: {total_doctors}")
