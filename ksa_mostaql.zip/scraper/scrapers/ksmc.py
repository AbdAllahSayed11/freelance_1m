# ksmc.py
import requests
from requests.structures import CaseInsensitiveDict
import logging
import json
import re
from time import sleep
from scraper.database import Database

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ksmc_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def scrape():
    """Scrape staff data from ksmc.med.sa using two APIs and store it in the database."""
    logger.info("Starting KSMC scraping process")
    
    # URLs for the two APIs
    list_url = "https://www.ksmc.med.sa/KSMC_Apps_Academy/screenservices/KSMC_UI_Academy_CW/MainFlow/StaffBlock/DataActionGetStaffAction"
    detail_url = "https://www.ksmc.med.sa/KSMC_Apps_Academy/screenservices/KSMC_UI_Academy_CW/MainFlow/StaffBlock/DataActionGetDataForItemAction"
    
    headers = CaseInsensitiveDict()
    headers["Host"] = "www.ksmc.med.sa"
    headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
    headers["Accept"] = "application/json"
    headers["Accept-Encoding"] = "deflate, gzip"
    headers["X-CSRFToken"] = "T6C+9iB49TLra4jEsMeSckDMNhQ="  # Note: May need dynamic token handling
    headers["Content-Type"] = "application/json; charset=UTF-8"

    session = requests.Session()
    adapter = requests.adapters.HTTPAdapter(max_retries=3)
    session.mount("https://", adapter)

    # Fetch staff list from the old API
    list_data = """
    {
      "versionInfo": {
        "moduleVersion": "vjQV5xY5ICgTKDUMD0unDA",
        "apiVersion": "CYMGzTCDfJkon5NYUfgYZw"
      },
      "viewName": "MainFlow.StaffScreen",
      "screenData": {}
    }
    """

    try:
        list_response = session.post(list_url, headers=headers, data=list_data, timeout=60)
        if list_response.status_code != 200:
            logger.error(f"Failed to fetch staff list. Status code: {list_response.status_code}")
            return
        staff_list = list_response.json().get("data", {}).get("StaffList", {}).get("List", [])
        logger.info(f"Retrieved {len(staff_list)} staff members from staff list API")
    except (requests.RequestException, json.JSONDecodeError) as e:
        logger.error(f"Error fetching staff list: {str(e)}")
        return

    if not staff_list:
        logger.error("No staff data retrieved from list API. Aborting scrape.")
        return

    # Process each staff member
    db = Database()
    total_doctors = 0
    for staff in staff_list:
        name_en = staff.get("NameEn", "N/A").strip()
        name_ar = staff.get("NameAr", "N/A").strip()
        staff_id = staff.get("Id", "N/A")
        info_en = staff.get("InformationEn", "")
        info_ar = staff.get("InformationAr", "")

        if name_en == "N/A" and name_ar == "N/A":
            logger.debug(f"Skipping staff ID {staff_id} due to missing names")
            continue

        # Parse specialty and location
        specialty_en = "N/A"
        specialty_ar = "N/A"
        location_en = "N/A"
        location_ar = "N/A"

        if info_en:
            specialty_match_en = re.search(r'>([^<]+)</span>', info_en, re.DOTALL)
            if specialty_match_en:
                specialty_en = specialty_match_en.group(1).strip()
            location_match_en = re.search(r'>(King Saud Medical City|PHC - [^\n<]+|[^\n<]+Hospital|Prince Sultan Center - [^\n<]+)</span>', info_en, re.DOTALL)
            if location_match_en:
                location_en = location_match_en.group(1).strip()

        if info_ar:
            specialty_match_ar = re.search(r'>([^<]+)</span>', info_ar, re.DOTALL)
            if specialty_match_ar:
                specialty_ar = specialty_match_ar.group(1).strip()
            location_match_ar = re.search(r'>(مدينة الملك سعود الطبية|مركز صحي - [^\n<]+|مستشفى [^\n<]+|مركز الأمير سلطان - [^\n<]+)</span>', info_ar, re.DOTALL)
            if location_match_ar:
                location_ar = location_match_ar.group(1).strip()

        # Fetch email from the second API
        email = "N/A"
        detail_data = f"""
        {{
          "versionInfo": {{
            "moduleVersion": "vjQV5xY5ICgTKDUMD0unDA",
            "apiVersion": "aQMZnKSr+CBBR8J1gG_oYQ"
          }},
          "viewName": "MainFlow.StaffScreen",
          "screenData": {{
            "variables": {{
              "StaffVar": {{
                "Id": "{staff_id}"
              }}
            }}
          }}
        }}
        """

        try:
            detail_response = session.post(detail_url, headers=headers, data=detail_data, timeout=60)
            if detail_response.status_code == 200:
                detail_json = detail_response.json()
                detail_info_en = detail_json.get("data", {}).get("Staff", {}).get("InformationEn", "")
                email_match = re.search(r'>([\w\.-]+@[\w\.-]+)</span>', detail_info_en, re.DOTALL)
                if email_match:
                    email = email_match.group(1).strip()
            else:
                logger.error(f"Failed to fetch details for ID {staff_id}. Status code: {detail_response.status_code}")
        except (requests.RequestException, json.JSONDecodeError) as e:
            logger.error(f"Error fetching details for ID {staff_id}: {str(e)}")

        profile_url = f"mailto:{email}" if email != "N/A" else "N/A"

        # Insert into database with image_url as "N/A"
        try:
            db.insert_doctor(
                name=name_en if name_en != "N/A" else name_ar,
                specialty=specialty_en if specialty_en != "N/A" else specialty_ar,
                location=location_en if location_en != "N/A" else location_ar,
                profile_url=profile_url,
                image_url="N/A",  # Added back to match expected argument
                source="ksmc.med.sa"
            )
            logger.debug(f"Added doctor: {name_en if name_en != 'N/A' else name_ar} - {specialty_en if specialty_en != 'N/A' else specialty_ar}")
            total_doctors += 1
        except Exception as e:
            logger.error(f"Failed to insert doctor {name_en if name_en != 'N/A' else name_ar}: {str(e)}")
            continue

        sleep(0.5)  # Avoid rate-limiting

    db.close()
    logger.info(f"KSMC scraping completed. Total doctors added: {total_doctors}")