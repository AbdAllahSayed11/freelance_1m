import requests
import logging
from bs4 import BeautifulSoup
from scraper.database import Database

# Configure logging to file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('kau_scraper.log', mode='w'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def fetch_page():
    """Fetch the HTML content from the target URL."""
    url = "https://hospital.kau.edu.sa/Content-599-En-243077"
    headers = {
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0",
        "Host": "hospital.kau.edu.sa"
    }

    try:
        logger.info(f"Sending GET request to {url}")
        response = requests.get(url, headers=headers, timeout=60)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page. Status code: {response.status_code}")
            return None

        logger.info("Successfully fetched page")
        return response.text

    except requests.RequestException as e:
        logger.error(f"Error fetching page from {url}: {str(e)}", exc_info=True)
        return None

def extract_doctor_data(html):
    """Extract doctor data from the HTML content."""
    if not html:
        return []

    # Try to use html5lib parser, fall back to html.parser if unavailable
    try:
        soup = BeautifulSoup(html, 'html5lib')
    except ValueError as e:
        if 'html5lib' in str(e):
            logger.error("The html5lib parser is required but not installed. Install it with 'pip install html5lib'.")
            logger.warning("Falling back to html.parser, which may lead to incomplete parsing.")
            soup = BeautifulSoup(html, 'html.parser')
        else:
            logger.error(f"Error creating BeautifulSoup object: {str(e)}")
            return []

    # Step 1: Find table by headers (Name, Position, Mobile Number, E-mail)
    tables = soup.find_all('table')
    target_table = None
    for table in tables:
        headers = [th.get_text(strip=True).lower() for th in table.find_all('th')]
        if 'name' in headers and 'position' in headers and 'mobile number' in headers and 'e-mail' in headers:
            target_table = table
            break

    # Step 2: Fallback - Find table with 5 columns
    if not target_table:
        for table in tables:
            rows = table.find_all('tr')
            if rows and len(rows[0].find_all('td')) == 5:
                target_table = table
                break

    if not target_table:
        logger.error("No suitable table found in the HTML")
        logger.debug(f"HTML snippet: {html[:1000]}")  # Log first 1000 chars for debugging
        return []

    rows = target_table.find_all('tr')[1:]  # Skip header row

    doctors = []
    for row in rows:
        cols = row.find_all('td')
        if len(cols) != 5:
            logger.warning(f"Skipping row with {len(cols)} columns (expected 5)")
            continue

        serial = cols[0].get_text(strip=True)
        name = cols[1].get_text(strip=True)
        position = cols[2].get_text(strip=True)
        phone = cols[3].get_text(strip=True).replace('\xa0', '').strip() or "N/A"
        email_tag = cols[4].find('a')
        email = email_tag.get_text(strip=True).replace(';', '') if email_tag else "N/A"

        if not name:
            logger.warning(f"Skipping row {serial} with missing name")
            continue

        profile_url = f"{email} - {phone}" if email != "N/A" or phone != "N/A" else "N/A"

        doctor_data = {
            "name": name,
            "specialty": position,
            "profile_url": profile_url,
            "source": "https://hospital.kau.edu.sa/Content-599-En-243077",
            "location": "مستشفى الملك عبدالعزيز الجامعي",  # Default location
            "image_url": "N/A"  # Default image URL
        }
        logger.debug(f"Extracted doctor data: {doctor_data}")
        doctors.append(doctor_data)

    logger.info(f"Extracted {len(doctors)} doctors from the table")
    return doctors

def scrape():
    """Main function to scrape doctor data and store it in the database."""
    logger.info("Starting King Abdulaziz University Hospital scraping process")

    db = Database()
    total_doctors = 0

    html = fetch_page()
    if not html:
        logger.warning("No HTML content fetched. Exiting.")
        db.close()
        return

    doctors = extract_doctor_data(html)
    if not doctors:
        logger.warning("No doctors extracted from the page. Exiting.")
        db.close()
        return

    for doctor_data in doctors:
        try:
            logger.debug(f"Attempting to insert doctor: {doctor_data}")
            db.insert_doctor(
                name=doctor_data["name"],
                specialty=doctor_data["specialty"],
                location=doctor_data["location"],
                profile_url=doctor_data["profile_url"],
                image_url=doctor_data["image_url"],
                source=doctor_data["source"]
            )
            total_doctors += 1
            logger.info(f"Added doctor: {doctor_data['name']} - {doctor_data['specialty']} (Total: {total_doctors})")
        except Exception as e:
            logger.error(f"Failed to insert doctor '{doctor_data['name']}': {str(e)}", exc_info=True)

    db.close()
    logger.info(f"KAU scraping completed. Total doctors added: {total_doctors}")
