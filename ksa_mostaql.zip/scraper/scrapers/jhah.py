# jhah.py
import requests
from requests.structures import CaseInsensitiveDict
import logging
import json
from time import sleep
from scraper.database import Database

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('jhah_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def scrape():
    """Scrape physician data from jhah.com and store it in the database."""
    logger.info("Starting JHAH scraping process")

    # API URL
    api_url = "https://www.jhah.com/umbraco/Api/PhysicianSearchApi/GetPhysicians?contentId=4616&gender=&keyword=&limit=700&location=&name=&page=1&specialty=&specialtyGroup="

    headers = CaseInsensitiveDict()
    headers["Host"] = "www.jhah.com"
    headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
    headers["Accept"] = "application/json, text/plain, */*"
    headers["Accept-Encoding"] = "gzip, deflate, br"

    session = requests.Session()
    adapter = requests.adapters.HTTPAdapter(max_retries=3)
    session.mount("https://", adapter)

    # Fetch physician data
    try:
        response = session.get(api_url, headers=headers, timeout=60)
        if response.status_code != 200:
            logger.error(f"Failed to fetch physician data. Status code: {response.status_code}")
            return
        physicians_data = response.json().get("physicians", {}).get("items", [])
        logger.info(f"Retrieved {len(physicians_data)} physicians from JHAH API")
    except (requests.RequestException, json.JSONDecodeError) as e:
        logger.error(f"Error fetching physician data: {str(e)}")
        return

    if not physicians_data:
        logger.error("No physician data retrieved from API. Aborting scrape.")
        return

    # Process each physician
    db = Database()
    total_doctors = 0
    base_url = "https://www.jhah.com"

    for physician in physicians_data:
        name = physician.get("name", "N/A").strip()
        professional_title = physician.get("professionalTitle", "N/A").strip()
        specialties = physician.get("specialties", [])
        locations = physician.get("locations", [])
        image_url = physician.get("imageUrl", "N/A")
        physician_page_url = physician.get("physicianPageUrl", "N/A")

        if name == "N/A":
            logger.debug("Skipping physician with missing name")
            continue

        # Use the first specialty and location if available
        specialty = specialties[0] if specialties else "N/A"
        location = locations[0] if locations else "N/A"

        # Convert physicianPageUrl to full URL
        profile_url = f"{base_url}{physician_page_url}" if physician_page_url != "N/A" else "N/A"

        # Prepend base URL to image_url if it’s a relative path
        if image_url != "N/A" and image_url.startswith("/"):
            image_url = f"{base_url}{image_url}"

        # Insert into database
        try:
            db.insert_doctor(
                name=name,
                specialty=specialty,
                location=location,
                profile_url=profile_url,
                image_url=image_url,
                source="jhah.com"
            )
            logger.debug(f"Added doctor: {name} - {specialty}")
            total_doctors += 1
        except Exception as e:
            logger.error(f"Failed to insert doctor {name}: {str(e)}")
            continue

        sleep(0.1)  # Small delay to avoid overwhelming the server

    db.close()
    logger.info(f"JHAH scraping completed. Total doctors added: {total_doctors}")

if __name__ == "__main__":
    scrape()