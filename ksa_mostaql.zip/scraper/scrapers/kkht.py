import requests
import logging
from bs4 import BeautifulSoup
from scraper.database import Database

# Configure logging to file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('kkht_scraper.log', mode='w'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def fetch_page():
    """Fetch the HTML content from the target URL."""
    url = "https://tabukhc.com/management-members/"
    headers = {
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0",
        "Host": "tabukhc.com"
    }

    try:
        logger.info(f"Sending GET request to {url}")
        response = requests.get(url, headers=headers, timeout=60)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page. Status code: {response.status_code}")
            return None

        logger.info("Successfully fetched page")
        return response.text

    except requests.RequestException as e:
        logger.error(f"Error fetching page from {url}: {str(e)}", exc_info=True)
        return None

def extract_doctor_data(html):
    """Extract management member data from the HTML content."""
    if not html:
        return []

    # Use html5lib parser for robust handling of HTML
    try:
        soup = BeautifulSoup(html, 'html5lib')
    except ValueError as e:
        if 'html5lib' in str(e):
            logger.error("The html5lib parser is required but not installed. Install it with 'pip install html5lib'.")
            logger.warning("Falling back to html.parser, which may lead to incomplete parsing.")
            soup = BeautifulSoup(html, 'html.parser')
        else:
            logger.error(f"Error creating BeautifulSoup object: {str(e)}")
            return []

    # Find all member widgets with class 'bdt-member'
    member_cards = soup.select('div.bdt-member.skin-default')
    if not member_cards:
        logger.error("No member cards found in the HTML")
        logger.debug(f"HTML snippet: {html[:1000]}")  # Log first 1000 chars for debugging
        return []

    doctors = []
    seen_members = set()  # To handle duplicates based on name
    for card in member_cards:
        # Extract name
        name_elem = card.find('span', class_='bdt-member-name')
        name = name_elem.get_text(strip=True) if name_elem else None

        # Extract role (treating as specialty)
        specialty_elem = card.find('span', class_='bdt-member-role')
        specialty = specialty_elem.get_text(strip=True) if specialty_elem else "N/A"

        # Skip if name is missing
        if not name:
            logger.warning("Skipping card with missing name")
            continue

        # Handle duplicates
        if name in seen_members:
            logger.debug(f"Skipping duplicate member: {name}")
            continue
        seen_members.add(name)

        # Extract image URL
        image_elem = card.find('img')
        image_url = image_elem['src'] if image_elem and 'src' in image_elem.attrs else "N/A"

        doctor_data = {
            "name": name,
            "specialty": specialty,
            "profile_url": "N/A",  # No profile links or emails provided
            "source": "https://tabukhc.com/management-members/",
            "location": "مستشفى الملك خالد - تبوك",  # Default location
            "image_url": image_url
        }
        logger.debug(f"Extracted member data: {doctor_data}")
        doctors.append(doctor_data)

    logger.info(f"Extracted {len(doctors)} unique members from the page")
    return doctors

def scrape():
    """Main function to scrape management member data and store it in the database."""
    logger.info("Starting King Khalid Hospital (Tabuk) scraping process")

    db = Database()
    total_doctors = 0

    html = fetch_page()
    if not html:
        logger.warning("No HTML content fetched. Exiting.")
        db.close()
        return

    doctors = extract_doctor_data(html)
    if not doctors:
        logger.warning("No members extracted from the page. Exiting.")
        db.close()
        return

    for doctor_data in doctors:
        try:
            logger.debug(f"Attempting to insert member: {doctor_data}")
            db.insert_doctor(
                name=doctor_data["name"],
                specialty=doctor_data["specialty"],
                location=doctor_data["location"],
                profile_url=doctor_data["profile_url"],
                image_url=doctor_data["image_url"],
                source=doctor_data["source"]
            )
            total_doctors += 1
            logger.info(f"Added member: {doctor_data['name']} - {doctor_data['specialty']} (Total: {total_doctors})")
        except Exception as e:
            logger.error(f"Failed to insert member '{doctor_data['name']}': {str(e)}", exc_info=True)

    db.close()
    logger.info(f"KKHT scraping completed. Total members added: {total_doctors}")
