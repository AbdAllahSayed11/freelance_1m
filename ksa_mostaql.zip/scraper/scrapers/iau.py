import requests
import logging
from bs4 import BeautifulSoup
from scraper.database import Database

# Configure logging to file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('iau_scraper.log', mode='w'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def fetch_page():
    """Fetch the HTML content from the target URL."""
    url = "https://fcmc.iau.edu.sa/Doctors.aspx"
    headers = {
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0",
        "Host": "fcmc.iau.edu.sa"
    }

    try:
        logger.info(f"Sending GET request to {url}")
        response = requests.get(url, headers=headers, timeout=60)
        if response.status_code != 200:
            logger.error(f"Failed to fetch page. Status code: {response.status_code}")
            return None

        logger.info("Successfully fetched page")
        return response.text

    except requests.RequestException as e:
        logger.error(f"Error fetching page from {url}: {str(e)}", exc_info=True)
        return None

def extract_doctor_data(html):
    """Extract doctor data from the HTML content."""
    if not html:
        return []

    # Use html5lib parser for robust handling of HTML
    try:
        soup = BeautifulSoup(html, 'html5lib')
    except ValueError as e:
        if 'html5lib' in str(e):
            logger.error("The html5lib parser is required but not installed. Install it with 'pip install html5lib'.")
            logger.warning("Falling back to html.parser, which may lead to incomplete parsing.")
            soup = BeautifulSoup(html, 'html.parser')
        else:
            logger.error(f"Error creating BeautifulSoup object: {str(e)}")
            return []

    # Find all doctor cards within the team-member section
    doctor_cards = soup.select('div.team-member div.col-md-3.col-sm-6')
    if not doctor_cards:
        logger.error("No doctor cards found in the HTML")
        logger.debug(f"HTML snippet: {html[:1000]}")  # Log first 1000 chars for debugging
        return []

    doctors = []
    for card in doctor_cards:
        # Extract from frontside
        frontside = card.select_one('.frontside .user-card')
        if not frontside:
            logger.warning("Skipping card with no frontside data")
            continue

        name_elem = frontside.select_one('.detfs p:first-child')
        name = name_elem.get_text(strip=True).replace('DR', '').strip() if name_elem else None
        specialty_elem = frontside.select_one('.detfs p:last-child')
        specialty = specialty_elem.get_text(strip=True) if specialty_elem else "N/A"

        if not name:
            logger.warning("Skipping card with missing name")
            continue

        # Extract from backside
        backside = card.select_one('.backside .card-body')
        if not backside:
            logger.warning(f"Skipping card for '{name}' with no backside data")
            continue

        email_elem = backside.select_one('.btn-link')
        email = email_elem.get_text(strip=True) if email_elem else "N/A"
        profile_url = email  # Per request, profile_url is just the email

        # Extract image URL
        image_elem = card.select_one('.userar input[type="image"]')
        image_url = image_elem['src'] if image_elem and 'src' in image_elem.attrs else "N/A"
        if image_url.startswith('uploads'):
            image_url = f"https://fcmc.iau.edu.sa/{image_url}"

        doctor_data = {
            "name": name,
            "specialty": specialty,
            "profile_url": profile_url,
            "source": "https://fcmc.iau.edu.sa/Doctors.aspx",
            "location": "مستشفى الملك فهد الجامعي",  # Default location
            "image_url": image_url
        }
        logger.debug(f"Extracted doctor data: {doctor_data}")
        doctors.append(doctor_data)

    logger.info(f"Extracted {len(doctors)} doctors from the page")
    return doctors

def scrape():
    """Main function to scrape doctor data and store it in the database."""
    logger.info("Starting King Fahd University Hospital scraping process")

    db = Database()
    total_doctors = 0

    html = fetch_page()
    if not html:
        logger.warning("No HTML content fetched. Exiting.")
        db.close()
        return

    doctors = extract_doctor_data(html)
    if not doctors:
        logger.warning("No doctors extracted from the page. Exiting.")
        db.close()
        return

    for doctor_data in doctors:
        try:
            logger.debug(f"Attempting to insert doctor: {doctor_data}")
            db.insert_doctor(
                name=doctor_data["name"],
                specialty=doctor_data["specialty"],
                location=doctor_data["location"],
                profile_url=doctor_data["profile_url"],
                image_url=doctor_data["image_url"],
                source=doctor_data["source"]
            )
            total_doctors += 1
            logger.info(f"Added doctor: {doctor_data['name']} - {doctor_data['specialty']} (Total: {total_doctors})")
        except Exception as e:
            logger.error(f"Failed to insert doctor '{doctor_data['name']}': {str(e)}", exc_info=True)

    db.close()
    logger.info(f"IAU scraping completed. Total doctors added: {total_doctors}")
