# fakeehcare.py
import requests
from bs4 import BeautifulSoup
import time
import logging
from scraper.database import Database

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('fakeehcare_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def get_specialty_links(base_url):
    """Get all specialty links from the base specialties page."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(base_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch base URL {base_url}. Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        specialty_links = []
        
        # Get links from footer section
        footer_links = soup.select('.footer6_link a[href^="/specialties/"]')
        for link in footer_links:
            full_url = f"https://en.dsfhjeddah.fakeeh.care{link['href']}"
            specialty_links.append(full_url)
        
        logger.info(f"Found {len(specialty_links)} specialty links")
        return specialty_links
        
    except requests.RequestException as e:
        logger.error(f"Error fetching specialty links from {base_url}: {str(e)}")
        return []

def extract_doctors(specialty_url):
    """Extract doctor information from a specialty page with flexible selectors."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(specialty_url, headers=headers, timeout=30)
        if response.status_code != 200:
            logger.error(f"Failed to fetch specialty page {specialty_url}. Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        doctor_items = soup.select('.doctors-item')
        
        doctors_data = []
        for item in doctor_items:
            # Try multiple classes for name
            name_elem = (item.select_one('.person-name') or 
                        item.select_one('.person-name-2'))
            name = name_elem.text.strip() if name_elem else "N/A"
            
            # Try multiple classes for specialty/job
            specialty_elem = (item.select_one('.person-job') or 
                            item.select_one('.person-expertise') or 
                            item.select_one('.person-expertise-2'))
            specialty = specialty_elem.text.strip() if specialty_elem else "N/A"
            
            # Get profile URL
            profile_link = item.select_one('.doctors-link-2') or item.select_one('.doctors-link')
            profile_url = f"https://en.dsfhjeddah.fakeeh.care{profile_link['href']}" if profile_link and profile_link.get('href') else "N/A"
            
            # Get image URL
            img_elem = item.select_one('.gallery_image')
            image_url = img_elem['src'] if img_elem and img_elem.get('src') else "N/A"
            
            # Location is consistently DSFH Jeddah from the sample
            location = "مستشفى الدكتور سليمان فقيه"
            
            if name != "N/A":
                doctors_data.append({
                    'name': name,
                    'specialty': specialty,
                    'location': location,
                    'profile_url': profile_url,
                    'image_url': image_url,
                    'source': specialty_url
                })
            else:
                logger.warning(f"Skipping doctor with missing name at {specialty_url}. Item HTML: {str(item)[:200]}...")  # Truncated for brevity
            
        logger.info(f"Extracted {len(doctors_data)} doctors from {specialty_url}")
        return doctors_data
        
    except requests.RequestException as e:
        logger.error(f"Error extracting doctors from {specialty_url}: {str(e)}")
        return []

def scrape():
    """Main function to scrape doctor data from fakeeh.care specialties pages."""
    base_url = "https://en.dsfhjeddah.fakeeh.care/specialties"
    logger.info("Starting Fakeeh Care scraping process")
    
    # Initialize database connection
    db = Database()
    
    # Get all specialty links
    specialty_links = get_specialty_links(base_url)
    if not specialty_links:
        logger.error("No specialty links found. Aborting scrape.")
        db.close()
        return
    
    total_doctors = 0
    # Process each specialty page
    for i, url in enumerate(specialty_links, 1):
        logger.info(f"Scraping specialty {i}/{len(specialty_links)}: {url}")
        doctors = extract_doctors(url)
        
        # Insert doctors into database
        for doctor in doctors:
            db.insert_doctor(
                name=doctor['name'],
                specialty=doctor['specialty'],
                location=doctor['location'],
                profile_url=doctor['profile_url'],
                image_url=doctor['image_url'],
                source=doctor['source']
            )
            logger.debug(f"Added doctor: {doctor['name']} - {doctor['specialty']}")
            total_doctors += 1
        
        # Respectful delay between requests
        time.sleep(2)
    
    db.close()
    logger.info(f"Fakeeh Care scraping completed. Total doctors added: {total_doctors}")
