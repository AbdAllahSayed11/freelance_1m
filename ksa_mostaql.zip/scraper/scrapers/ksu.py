import requests
from bs4 import BeautifulSoup
from time import sleep
from scraper.database import Database

def extract_doctor_data(doctor_card):
    """Extracts the doctor data from the HTML card."""
    try:
        # Doctor's name
        name = doctor_card.select_one('h5').text.strip()
        
        # Skip if the name is empty or contains non-doctor related text
        if not name or "Share it:" in name:
            return None
        
        # Specialty or description
        specialty = doctor_card.select_one('span').text.strip()

        # Profile image URL
        image_url = doctor_card.select_one('img')['src']
        
        # Doctor's profile link (assumes that profile image is linked)
        profile_url = doctor_card.select_one('a')['href'] if doctor_card.select_one('a') else "N/A"

        # Ensure the profile URL is a valid doctor URL and not social media or share link
        if "facebook.com" in profile_url or "twitter.com" in profile_url or "pinterest.com" in profile_url:
            return None

        return {
            'name': name,
            'specialty': specialty,
            'image_url': image_url,
            'profile_url': profile_url,
            'source': 'https://medicalcity.ksu.edu.sa'
        }
    except Exception as e:
        print(f"Error extracting doctor data: {e}")
        return None

def scrape_page(page_url):
    """Scrapes a single page of doctors' information."""
    try:
        response = requests.get(page_url)
        if response.status_code != 200:
            print(f"Failed to fetch page {page_url}. Status code: {response.status_code}")
            return []

        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find doctor entries
        doctor_cards = soup.select('.col-post')
        doctors_data = []
        
        for card in doctor_cards:
            doctor_data = extract_doctor_data(card)
            if doctor_data:
                doctors_data.append(doctor_data)
        
        print(f"Extracted {len(doctors_data)} doctors from {page_url}")
        return doctors_data

    except requests.RequestException as e:
        print(f"Error scraping page {page_url}: {str(e)}")
        return []

def scrape():
    """Scrapes the doctors' data from all pages (P01 to P15)."""
    print("Starting King Saud University Medical City scraping process")

    db = Database()
    total_doctors = 0
    base_url = "https://medicalcity.ksu.edu.sa/en/doctorsad/"

    # Loop through all pages P01 to P15
    for page_num in range(1, 16):
        page_url = f"{base_url}P{str(page_num).zfill(2)}"
        print(f"Scraping page {page_num}: {page_url}")
        
        doctors = scrape_page(page_url)
        
        for doctor in doctors:
            try:
                db.insert_doctor(
                    name=doctor['name'],
                    specialty=doctor['specialty'],
                    location="مستشفى الملك خالد الجامعي",  # Location is fixed
                    profile_url=doctor['profile_url'],
                    image_url=doctor['image_url'],
                    source=doctor['source']
                )
                print(f"Added doctor: {doctor['name']} - {doctor['specialty']}")
                total_doctors += 1
            except Exception as e:
                print(f"Failed to insert doctor {doctor['name']}: {str(e)}")
        
        # Respectful delay between pages
        sleep(2)

    db.close()
    print(f"KSU Medical City scraping completed. Total doctors added: {total_doctors}")
