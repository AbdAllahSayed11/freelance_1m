import requests
from bs4 import BeautifulSoup

# XAI API Key
API_KEY = "xai-AJhCFYRfBPDC3JG5gTj83ml8I8AW6DfutoJ1zmXkvOKQxajHLu0ZflENMDHIYDDxbHu0edGBxHdCXRQB"

# Step 1: Search doctor name on the web and extract social media profiles
def search_doctor_profiles(doctor_name):
    # Search for the doctor's name on LinkedIn, Instagram, and Facebook
    search_urls = [
        f"https://www.linkedin.com/search/results/people/?keywords={doctor_name}",
        f"https://www.instagram.com/{doctor_name}",
        f"https://www.facebook.com/{doctor_name}"
    ]
    
    # A simple request to find the profile URLs - you can improve this with more complex scraping logic
    profile_links = []
    for url in search_urls:
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            # Check if we find a relevant link (this part depends on the platform's structure)
            profile_links.append(url)  # Just adding the search URL for now
    
    return profile_links

# Step 2: Use the XAI API to get the similarity scores for the profiles
def get_profile_similarity(profile_links, doctor_name):
    url = "https://api.xai.com/compare"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    data = {
        "doctor_name": doctor_name,
        "profile_links": profile_links
    }
    
    response = requests.post(url, json=data, headers=headers)
    if response.status_code == 200:
        return response.json()  # Returns similarity scores for each profile
    else:
        return None

# Step 3: Use the function to get the best profile
def find_best_doctor_profile(doctor_name):
    # Step 1: Search for profiles
    profile_links = search_doctor_profiles(doctor_name)
    
    if not profile_links:
        return "No profiles found."
    
    # Step 2: Get similarity scores
    similarity_scores = get_profile_similarity(profile_links, doctor_name)
    
    if similarity_scores:
        # Select the profile with the highest score
        best_profile = max(similarity_scores, key=lambda x: x['score'])
        return f"Best profile: {best_profile['url']} with a score of {best_profile['score']}"
    else:
        return "Error fetching similarity scores."

# Example usage
doctor_name = "Dr. Riham Ghanim"
result = find_best_doctor_profile(doctor_name)
print(result)
